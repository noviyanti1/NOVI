
</div>
      </div>
    </div>
  <script src="<?php echo base_url();?>assets/vendors/base/vendor.bundle.base.js"></script>
  <script src="<?php echo base_url();?>assets/js/off-canvas.js"></script>
  <script src="<?php echo base_url();?>assets/js/hoverable-collapse.js"></script>
  <script src="<?php echo base_url();?>js/template.js"></script>
  <script src="<?php echo base_url();?>assets/vendors/chart.js/Chart.min.js"></script>
  <script src="<?php echo base_url();?>assets/vendors/jquery-bar-rating/jquery.barrating.min.js"></script>
  <script src="<?php echo base_url();?>assets/js/dashboard.js"></script>
  </body>

</html>