<?php $this->load->view('template/head'); ?>
<?php $this->load->view('template/sidebar'); ?>

  <div class="content-wrapper">
    <div class="container-xxl flex-grow-1 container-p-y">
      <div class="row">
        <div class="card" style="min-width: 1000px; min-height: 600px;">
          <div class="card-body">
            <h5 class="card-title">DATA BARANG</h5> <a href="<?php echo site_url('barang/tambah'); ?>" class="btn btn-primary mb-3">Tambah Barang</a> <div class="table-responsive" style="overflow-x: auto;">
              <table class="table table-striped table-bordered">
                <thead>
                  <tr>
                    <th>No</th> <th>NAMA BARANG</th> <th>KATEGORI</th> <th>HARGA</th>
                    <th>STOK</th>
                    <th>AKSI</th>
                  </tr>
                </thead>
                <tbody>
                  <?php if (empty($barang)): ?> <tr><td colspan="6">Tidak ada data barang.</td></tr> <?php else: ?>
                    <?php
                    $NO = 1; 
                      foreach ($barang as $row): ?> <tr>
                        <td><?php echo $NO++; ?></td> <td><?php echo $row['nama_brg']; ?></td> <td><?php echo $row['kategori']; ?></td> <td>Rp <?php echo number_format($row['harga'], 2, ',', '.'); ?></td>
                        <td><?php echo $row['stok']; ?></td>
                        <td>
                          <a href="<?php echo site_url('barang/edit/' . $row['id_barang']); ?>">Edit</a> | <a href="<?php echo site_url('barang/hapus/' . $row['id_barang']); ?>" onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?')">Hapus</a> </td>
                      </tr>
                    <?php endforeach; ?>
                  <?php endif; ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
<?php $this->load->view('template/footer'); ?>