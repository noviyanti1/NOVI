<?php $this->load->view('template/head'); ?>
<?php $this->load->view('template/sidebar'); ?>

  <div class="content-wrapper">
    <div class="container-xxl flex-grow-1 container-p-y">
      <div class="row">
        <div class="card" style="min-width: 600px;">
          <div class="card-body">
            <h5 class="card-title">EDIT BARANG</h5>
            <form action="<?php echo site_url('barang/edit_aksi'); ?>" method="post">
              <input type="hidden" name="id_barang" value="<?php echo $barang['id_barang']; ?>">
              <div class="mb-3">
                <label for="nama_brg" class="form-label">Nama Barang</label>
                <input type="text" class="form-control" id="nama_brg" name="nama_brg" value="<?php echo $barang['nama_brg']; ?>" required>
              </div>
              <div class="mb-3">
                <label for="kategori" class="form-label">Kategori</label>
                <input type="text" class="form-control" id="kategori" name="kategori" value="<?php echo $barang['kategori']; ?>" required>
              </div>
              <div class="mb-3">
                <label for="harga" class="form-label">Harga</label>
                <input type="number" class="form-control" id="harga" name="harga" value="<?php echo $barang['harga']; ?>" required>
              </div>
              <div class="mb-3">
                <label for="stok" class="form-label">Stok</label>
                <input type="number" class="form-control" id="stok" name="stok" value="<?php echo $barang['stok']; ?>" required>
              </div>
              <button type="submit" class="btn btn-primary">Simpan</button>
              <a href="<?php echo site_url('barang'); ?>" class="btn btn-secondary">Batal</a>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>

<?php $this->load->view('template/footer'); ?>