<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Barang_m extends CI_Model { // Ubah nama class menjadi Barang_m

    private $table = 'tb_barang'; // Nama tabel di database

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

    public function get_all()
    {
        return $this->db->get($this->table)->result_array();
    }

    public function insert_barang($data) // Ubah nama method menjadi insert_barang
    {
        return $this->db->insert($this->table, $data);
    }

    public function get_by_id($id)
    {
        return $this->db->get_where($this->table, ['id_barang' => $id])->row_array(); // Ubah where clause menjadi 'id_barang'
    }

    public function update_barang($id, $data) // Ubah nama method menjadi update_barang
    {
        $this->db->where('id_barang', $id); // Ubah where clause menjadi 'id_barang'
        return $this->db->update($this->table, $data);
    }

    public function delete_barang($id) // Ubah nama method menjadi delete_barang
    {
        $this->db->where('id_barang', $id); // Ubah where clause menjadi 'id_barang'
        return $this->db->delete($this->table);
    }
}