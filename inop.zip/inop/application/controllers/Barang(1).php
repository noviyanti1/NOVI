<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Barang extends CI_Controller { // Ubah nama class menjadi Barang

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Barang_m'); // Ubah nama model menjadi Barang_m
    }

    public function index()
    {
        $data['barang'] = $this->Barang_m->get_all(); // Ubah nama variabel dan pemanggilan model
        $this->load->view('barang', $data); // Ubah nama view menjadi barang/index
    }

    public function tambah()
    {
        $this->load->view('tambah'); // Ubah nama view menjadi barang/tambah
    }

    public function tambah_aksi()
    {
        $nama_brg = $this->input->post('nama_brg');
        $kategori = $this->input->post('kategori');
        $harga = $this->input->post('harga');
        $stok = $this->input->post('stok');

        $data = array(
            'nama_brg' => $nama_brg,
            'kategori' => $kategori,
            'harga' => $harga,
            'stok' => $stok
        );

        $this->Barang_m->insert_barang($data); // Ubah nama method model
        redirect('barang'); // Ubah redirect menjadi 'barang'
    }

    public function edit($id)
    {
        $data['barang'] = $this->Barang_m->get_by_id($id); // Ubah nama variabel dan method model
        $this->load->view('edit', $data); // Ubah nama view menjadi barang/edit
    }

    public function edit_aksi()
    {
        $id_barang = $this->input->post('id_barang'); // Ubah nama input menjadi 'id_barang'
        $nama_brg = $this->input->post('nama_brg');
        $kategori = $this->input->post('kategori');
        $harga = $this->input->post('harga');
        $stok = $this->input->post('stok');

        $data = array(
            'nama_brg' => $nama_brg,
            'kategori' => $kategori,
            'harga' => $harga,
            'stok' => $stok
        );

        $this->Barang_m->update_barang($id_barang, $data); // Ubah nama method model dan parameter id
        redirect('barang'); // Ubah redirect menjadi 'barang'
    }

    public function hapus($id)
    {
        $this->Barang_m->delete_barang($id); // Ubah nama method model
        redirect('barang'); // Ubah redirect menjadi 'barang'
    }
}